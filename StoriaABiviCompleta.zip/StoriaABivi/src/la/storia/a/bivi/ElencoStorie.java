package la.storia.a.bivi;

import java.util.LinkedList;

/**
 * Classe che gestisce un elenco di storie, modulo 1
 * @author User
 *
 */
public class ElencoStorie {
	
	private LinkedList<Storia> elencoStorie=new LinkedList<Storia>();
	private String nome;
	
	public ElencoStorie(String nome) {
		this.nome=nome;
	}
	/**
	 * cerca la storia sulla base del titolo, ti informa solo se � presente o meno
	 * @param titolo
	 * @return
	 */
	public int cercaStoria(String titolo) {
		for(int i=0;i<elencoStorie.size();i++)
			if(elencoStorie.get(i).getTitolo().equals(titolo))
				return i;//trovato
		return -1;//non trovato
	}
	/**
	 * stampa tutti i titoli delle storie disponibili
	 */
	public void visualizzaTitoliStorie() {
		for(int i=0;i<elencoStorie.size();i++) {
			System.out.println(elencoStorie.get(i).getTitolo());
			stampaSpecificheStoria(elencoStorie.get(i));
			System.out.println("---------------------------------");
		}
	}
	/**
	 * consente di scegliere una storia e di iniziare a giocarla se memorizzata in un oggetto
	 * di tipo Storia
	 * @param titolo
	 * @return
	 */
	public Storia giocaStoria(String titolo) {
		int trovato=cercaStoria(titolo);//cerca se il titolo � presente
		if(trovato!=-1) {//� presente oppure no
			return elencoStorie.get(trovato);
		}
		return null;
	}
	/**
	 * ordino le storie sulla base del loro numero di paragrafi mediante un quickSort
	 * @param elencoStorie
	 * @return
	 */
	public LinkedList<Storia> quickSortPerParagrafi(LinkedList<Storia> elencoStorie){
		if(elencoStorie.size()<=1) {
			return elencoStorie;
		}
		Storia pivot=elencoStorie.get(elencoStorie.size()/2);//prendo come pivot l'elemento centrale
		LinkedList<Storia> sottoLista1=new LinkedList<Storia>(); //contiene i valori pi� piccoli del pivot
		LinkedList<Storia> sottoLista2=new LinkedList<Storia>();//contiene i valori pi� grandi del pivot
		for(int i=0;i<elencoStorie.size();i++) {
			if(i==elencoStorie.size()/2) //stai analizzando il pivot, non ti interessa
				continue;
			if(pivot.getNumeroParagrafi()<elencoStorie.get(i).getNumeroParagrafi())
				sottoLista2.add(elencoStorie.get(i));
			else
				sottoLista1.add(elencoStorie.get(i));
		}
		LinkedList<Storia> risultato=new LinkedList<Storia>();
		LinkedList<Storia> paragrafiMinori=quickSortPerParagrafi(sottoLista1);//ordino prima la sottolista minore
		LinkedList<Storia> paragrafiMaggiori=quickSortPerParagrafi(sottoLista2);//ordino la sottolista maggiore
		//aggiungo tutti i risultati alla lista risultante da tutto ci�. La LinkedList ha temi di esecuzione
		//del quickSort superiori di un ArrayList in quanto opera con i puntatori
		risultato.addAll(paragrafiMinori); risultato.add(pivot); risultato.addAll(paragrafiMaggiori);
		return risultato;
	}
	
	public void stampaSpecificheStoria(Storia storia) {
		System.out.println("Ha una verbosit� di: "+storia.getVerbosita());
		System.out.println("Ha una complessit� di: "+storia.getComplessitaIntreccio());
		System.out.println("Ha una dimensione di: "+storia.dimensione());
	}
	public LinkedList<Storia> getElencoStorie() {
		return elencoStorie;
	}
	public void setElencoStorie(LinkedList<Storia> elencoStorie) {
		this.elencoStorie = elencoStorie;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void aggiungiStoria(Storia storia) {
		elencoStorie.add(storia);
	}

}
