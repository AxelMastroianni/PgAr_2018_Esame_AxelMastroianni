package la.storia.a.bivi;

import java.util.InputMismatchException;
import java.util.Scanner;

public class GiocoDelleStorie {
	
	public static Storia creaStoria() {
		Scanner tastiera=new Scanner(System.in);
		System.out.println("Nomina la tua storia: ");
		String nomeStoria=tastiera.nextLine();
		return new Storia(nomeStoria);
	}
	
	public static Paragrafo creaParagrafo(int id) {
		Scanner tastiera=new Scanner(System.in);
		System.out.println("Descrivi il tuo paragrafo: ");
		String nomeParagrafo=tastiera.nextLine();
		System.out.println("Quante opzioni gli metti? ");
		int numeroOpzioni=tastiera.nextInt();
		return new Paragrafo(id,nomeParagrafo,numeroOpzioni);
	}
	
	public static Opzione creaOpzione(int paragrafoRiferimento) {
		Scanner tastiera=new Scanner(System.in);
		System.out.println("Descrivi la tua opzione: ");
		String descrizione=tastiera.nextLine();
		return new Opzione(descrizione, paragrafoRiferimento);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tastiera=new Scanner(System.in);
		int numeroStorie=0;
		int scegli=0;
		String risposta="";
		while(!risposta.equals("no")) {
		System.out.println("Scegli cosa fare: ");
		System.out.println("1. Crea una storia;");
		System.out.println("2. Gioca una storia.");
		scegli=tastiera.nextInt();
		ElencoStorie elenco=new ElencoStorie("Biblioteca");
		switch(scegli) {
		case 2:{
		System.out.println("Quante storie vuoi giocare? ");
		numeroStorie=tastiera.nextInt();
		for(int i=0;i<numeroStorie;i++) {
			switch(i) {
			case 0:{
				LeggiXMLStorie lettore1=new LeggiXMLStorie();
				Storia s1=lettore1.explore("./src/PgAr2018_Story_2.1.xml");
				elenco.aggiungiStoria(s1);
				break;
			}
			case 1:{
				LeggiXMLStorie lettore2=new LeggiXMLStorie();
				Storia s2=lettore2.explore("./src/PgAr2018_Story_2.2.xml");
				elenco.aggiungiStoria(s2);
				break;
			}
			case 2:{
				LeggiXMLStorie lettore3=new LeggiXMLStorie();
				Storia s3=lettore3.explore("./src/PgAr2018_Story_2.3.xml");
				elenco.aggiungiStoria(s3);
				break;
			}
			default:{
				int numeroParagrafi=0;
				System.out.println("Quanti paragrafi vuoi nella storia? ");
				try {//controllo sul dato inserito, se errato, esce da ciclo
					numeroParagrafi=tastiera.nextInt();
				}catch(InputMismatchException e) {
					System.out.println("Errore, riprova");
					continue;
				}
				System.out.println("Inserisci il nome della storia: ");
				String nomeStoria=tastiera.nextLine();
				Storia storia=new Storia(nomeStoria,numeroParagrafi);
				elenco.aggiungiStoria(storia);
				break;
			}
			}
		}
		String scegliStoria;
		elenco.visualizzaTitoliStorie();//stampa i titoli con relative specifiche
		System.out.println("Scegli una storia da giocare: ");
		tastiera.nextLine(); //metodo apocrifo
		try {
		scegliStoria=tastiera.nextLine();
		}catch(InputMismatchException e) {
			System.out.println("Dato non corretto.");
			scegliStoria=tastiera.nextLine();
		}
		Storia giocabile=elenco.giocaStoria(scegliStoria);
		giocabile.aggiustaPrimoParagrafo();
		giocabile.rimuoviRidondanze();
		giocabile.rimuoviOpzioniUltimoParagrafo();
		int scelta=0;
		while(scelta!=-1) {
			scelta=giocabile.scegliOpzione(scelta);
		}
		System.out.println("La storia � terminata!");
		break;
		}
		case 1:{
			Storia miaStoria=creaStoria();
			System.out.println("Quanti paragrafi vuoi nella tua storia? ");
			int numeroParagrafi=tastiera.nextInt();
			for(int i=0;i<numeroParagrafi;i++) {
				Paragrafo paragrafo=creaParagrafo(i);
				for(int j=0;j<paragrafo.getNumeroOpzioni();j++) {
					System.out.println("A che paragrafo punta? ");
					int paragrafoRiferito=tastiera.nextInt();
					if(paragrafoRiferito>numeroParagrafi) {
						System.out.println("Paragrafo inesistente");
						j--;//non c'� avanzamento
					}
					else {
						Opzione opzione=creaOpzione(paragrafoRiferito);
						paragrafo.aggiungiOpzione2(opzione);
					}
				}
				miaStoria.aggiungiParagrafo(paragrafo);
			}
			elenco.aggiungiStoria(miaStoria);
		}
		}
		System.out.println("Vuoi giocare ancora? "); risposta=tastiera.next();
		}

	}

}
