package la.storia.a.bivi;

import java.util.ArrayList;
import java.util.Random;

public class Paragrafo {
	
	public static final int MASSIME_OPZIONI=5;
	private String descrizione;
	private int id;
	private ArrayList<Opzione> listaOpzioni = new ArrayList<Opzione>();
	private int numeroOpzioni;
	private Random r = new Random();
	
	public Paragrafo(int id, String descrizione) {
		this.id=id;
		this.descrizione=descrizione;
		numeroOpzioni=Math.abs(r.nextInt()%MASSIME_OPZIONI);
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ArrayList<Opzione> getListaOpzioni() {
		return listaOpzioni;
	}

	public void setListaOpzioni(ArrayList<Opzione> listaOpzioni) {
		this.listaOpzioni = listaOpzioni;
	}

	public int getNumeroOpzioni() {
		return numeroOpzioni;
	}

	public void setNumeroOpzioni(int numeroOpzioni) {
		this.numeroOpzioni = numeroOpzioni;
	}
	/**
	 * controlla che un paragrafo non abbia le stesse opzioni, in questo modo non c'� il pericolo
	 * che due opzioni diverse si riferiscano allo stesso paragrafo
	 */
	public void controllaOpzioni() {
		int i=0;
		while(i<listaOpzioni.size()) {
			int dimensionePartenza=listaOpzioni.size();
			int idPuntato=listaOpzioni.get(i).getIdParagrafoRiferito();
			for(int j=0;j<listaOpzioni.size();j++) {
				int puntatoreJ=listaOpzioni.get(j).getIdParagrafoRiferito();
				if(j==i && puntatoreJ!=id) //se puntatoreJ � uguale all'id procede subito a rimuoverlo
					continue;//se i � uguale a j vuol dire che sta analizzando idPuntato, evita la sua rimozione
				if(idPuntato==puntatoreJ || puntatoreJ==id)
					listaOpzioni.remove(j);
			}
			if(dimensionePartenza==listaOpzioni.size())//i aumenta solo se non rimuovo nulla
				i++; //evita di lasciare alcuni id puntati incontrollati
		}
	}
	/**
	 * aggiunge l'opzione al paragrafo solo se non ho raggiunto il numero massimo, altrimenti il metodo
	 * va a vuoto per evitare di far crasshare il programma
	 * @param nome
	 */
	public void aggiungiOpzione(String nome, int idParagrafo) {
		if(listaOpzioni.size()<numeroOpzioni) {
			listaOpzioni.add(new Opzione(nome,idParagrafo));
		}
		return;
	}
	
	public void rimuoviOpzioni() {
		while(!listaOpzioni.isEmpty())
			listaOpzioni.remove(0);
	}

}
