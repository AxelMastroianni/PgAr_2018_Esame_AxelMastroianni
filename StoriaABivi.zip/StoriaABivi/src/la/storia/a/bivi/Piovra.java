package la.storia.a.bivi;

import java.util.LinkedList;
import java.util.Scanner;

public class Piovra {
	
	
	public static void main(String[] args) {
		
		
		Scanner tastiera=new Scanner(System.in);
		int scelta=0;
		ElencoStorie elenco=new ElencoStorie("Biblioteca");
		LeggiXMLStorie lettore = new LeggiXMLStorie();
		//nella versione corretta saranno lette tutte con un ciclo poi saranno stampate a menu
		//e l'utente potr� scegliere una storia. Se esiste si pu� giocare
		Storia s=lettore.explore("./src/PgAr2018_Story_2."+1+".xml");s.creaStoria();
		elenco.aggiungiStoria(s);
		LeggiXMLStorie lettore2=new LeggiXMLStorie();
		Storia s2=lettore2.explore("./src/PgAr2018_Story_2.2.xml");s2.creaStoria();
		elenco.aggiungiStoria(s2);
		LeggiXMLStorie lettore3=new LeggiXMLStorie();
		Storia s3=lettore3.explore("./src/PgAr2018_Story_2.3.xml"); s3.creaStoria();  elenco.aggiungiStoria(s3);
		LinkedList<Storia> elencoStorie=elenco.getElencoStorie();
		for(Storia storia : elencoStorie) {
			storia.aggiustaPrimoParagrafo();
			storia.rimuoviRidondanze();
			storia.rimuoviOpzioniUltimoParagrafo();
		}
		for(Storia storia: elencoStorie) {
			while(scelta!=-1) {
				scelta=storia.scegliOpzione(scelta);
			}
			System.out.println("Storia terminata");
			scelta=0;
		}
		System.out.println("Bravo, hai terminato tutte le storie!");

	}
	
}
