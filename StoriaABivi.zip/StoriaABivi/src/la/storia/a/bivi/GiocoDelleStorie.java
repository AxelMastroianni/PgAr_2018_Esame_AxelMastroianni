package la.storia.a.bivi;

import java.util.InputMismatchException;
import java.util.Scanner;

public class GiocoDelleStorie {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tastiera=new Scanner(System.in);
		int numeroStorie=0;
		ElencoStorie elenco=new ElencoStorie("Biblioteca");
		System.out.println("Quante storie vuoi giocare? ");
		numeroStorie=tastiera.nextInt();
		for(int i=0;i<numeroStorie;i++) {
			switch(i) {
			case 0:{
				LeggiXMLStorie lettore1=new LeggiXMLStorie();
				Storia s1=lettore1.explore("./src/PgAr2018_Story_2.1.xml");
				elenco.aggiungiStoria(s1);
				break;
			}
			case 1:{
				LeggiXMLStorie lettore2=new LeggiXMLStorie();
				Storia s2=lettore2.explore("./src/PgAr2018_Story_2.2.xml");
				elenco.aggiungiStoria(s2);
				break;
			}
			case 2:{
				LeggiXMLStorie lettore3=new LeggiXMLStorie();
				Storia s3=lettore3.explore("./src/PgAr2018_Story_2.3.xml");
				elenco.aggiungiStoria(s3);
				break;
			}
			default:{
				int numeroParagrafi=0;
				System.out.println("Quanti paragrafi vuoi nella storia? ");
				try {
					numeroParagrafi=tastiera.nextInt();
				}catch(InputMismatchException e) {
					System.out.println("Errore, riprova");
					continue;
				}
				System.out.println("Inserisci il nome della storia: ");
				String nomeStoria=tastiera.next();
				Storia storia=new Storia(nomeStoria,numeroParagrafi);
				elenco.aggiungiStoria(storia);
				break;
			}
			}
		}
		for(Storia storia : elenco.getElencoStorie()) {
			storia.creaStoria();
			storia.aggiustaPrimoParagrafo();
			storia.rimuoviRidondanze();
			storia.rimuoviOpzioniUltimoParagrafo();
			System.out.println(storia.getTitolo());
			int scelta=0;
			while(scelta!=-1) {
				scelta=storia.scegliOpzione(scelta);
			}
			System.out.println("Storia terminata!");
		}
		System.out.println("Complimenti, hai terminato tutte le storie");

	}

}
