package la.storia.a.bivi;

public class Opzione {
	
	private String descrizione;
	private int idParagrafoRiferito;
	
	public Opzione(String descrizione, int idParagrafoRiferito) {
		this.descrizione=descrizione;
		this.idParagrafoRiferito=idParagrafoRiferito;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public int getIdParagrafoRiferito() {
		return idParagrafoRiferito;
	}

	public void setIdParagrafoRiferito(int idParagrafoRiferito) {
		this.idParagrafoRiferito = idParagrafoRiferito;
	}
	
	

}
