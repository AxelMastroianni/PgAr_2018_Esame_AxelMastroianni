package la.storia.a.bivi;

import java.io.FileInputStream;
import java.util.ArrayList;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

public class LeggiXMLStorie {
	
	private ArrayList<Paragrafo> paragrafiStoria=new ArrayList<Paragrafo>();
	private Storia storia;
	private int i=-1; //conta i paragrafi
	
	public Storia explore(String filename) {
		try {
			int numeroOpzioni=0;
			XMLInputFactory xmlif=XMLInputFactory.newInstance();
	        XMLStreamReader xmlr = xmlif.createXMLStreamReader(filename,
	                                   new FileInputStream(filename));
	        while(xmlr.hasNext()) {
	            switch(xmlr.getEventType()) {
	            case XMLStreamConstants.START_ELEMENT:{
	            	switch(xmlr.getLocalName()) {
	            	case "paragraph":{
	            		numeroOpzioni=0;
	            		i++;
	            		int id=0;
	            		id=Integer.parseInt(xmlr.getAttributeValue(0));
	            		paragrafiStoria.add(new Paragrafo(id,""));
	            		break;
	            	}
	            	case "description":{
	            		String descrizione="";
	            		xmlr.next();//va avanti in modo da leggere il testo
	            		String testo=xmlr.getText();
	            		if(testo.trim().length()>0)
	            			descrizione=testo;
	            		paragrafiStoria.get(i).setDescrizione(descrizione);
	            		break;
	            	}
	            	case "option":{
	            		int idParagrafoRiferito=Integer.parseInt(xmlr.getAttributeValue(0));
	            		numeroOpzioni++;
	            		paragrafiStoria.get(i).setNumeroOpzioni(numeroOpzioni);
	            		String descrizione="";
	            		xmlr.next();
	            		String testo=xmlr.getText();
	            		if(testo.trim().length()>0)
	            			descrizione=testo;
	            		paragrafiStoria.get(i).aggiungiOpzione(descrizione, idParagrafoRiferito);
	            		break;
	            	}
	            	case "story":{
	            		String titolo=xmlr.getAttributeValue(0);//il titolo � sempre in posizione 0
	            		int numeroParagrafi=Integer.parseInt(xmlr.getAttributeValue(1));//titolo in posizione 1
	            		storia=new Storia(titolo,numeroParagrafi);
	            		break;
	            	}
	            	}
	            }
	            default:
	            	break;
	            }
	            xmlr.next();
	        }
	        storia.setListaParagrafi(paragrafiStoria);
	        return storia;
	    }catch(Exception e){
	    	System.err.println("Error detected");
	    	System.err.println(e.getMessage());
	    	return null;
	    }
	}
	
	public ArrayList<Paragrafo> getParagrafi(){
		return paragrafiStoria;
	}
	
	public void svuotaArrayList() {
		while(!paragrafiStoria.isEmpty())
			paragrafiStoria.remove(0);
	}
	
	public int getI() {
		return i;
	}

}
