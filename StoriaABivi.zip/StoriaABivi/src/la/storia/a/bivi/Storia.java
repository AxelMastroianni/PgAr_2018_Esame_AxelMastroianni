package la.storia.a.bivi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class Storia {
	
	private Map<Integer, LinkedList<Paragrafo>> storiaABivi=new HashMap<Integer,LinkedList<Paragrafo>>();
	private ArrayList<Paragrafo> listaParagrafi=new ArrayList<Paragrafo>();
	private String titolo;
	private int numeroParagrafi;
	private Random r = new Random();
	private Scanner tastiera = new Scanner(System.in);
	/**
	 * inizializza la lista di paragrafi e attacca ad ognuno un numero casuale di opzioni
	 * @param nome
	 * @param numeroParagrafi
	 */
	public Storia(String titolo, int numeroParagrafi) {
		this.titolo=titolo;
		this.numeroParagrafi=numeroParagrafi;
		if(numeroParagrafi>0) {
			for(int i=0;i<numeroParagrafi;i++) {
				storiaABivi.put(i, new LinkedList<Paragrafo>());
			}
			for(int i=0;i<numeroParagrafi;i++) {
				Paragrafo paragrafo=new Paragrafo(i,"Paragrafo "+i);
				listaParagrafi.add(paragrafo);
				for(int j=0;j<paragrafo.getNumeroOpzioni();j++) {
					int idParagrafo=Math.abs(r.nextInt()%numeroParagrafi);
					paragrafo.aggiungiOpzione("Opzione "+i, idParagrafo);
				}
			}
		}
		else
			throw new IllegalArgumentException("Numero Paragrafi irrealizzabile");
	}
	
	public void creaStoria() {
		for(int i=0;i<numeroParagrafi;i++) {
			Paragrafo riferimento=listaParagrafi.get(i);
			LinkedList<Paragrafo> paragrafiCollegati=storiaABivi.get(i);
			ArrayList<Opzione> listaOpzioni=riferimento.getListaOpzioni();
			for(int j=0;j<listaOpzioni.size();j++) {
				Opzione opzione=listaOpzioni.get(j);
				int idRiferimento=opzione.getIdParagrafoRiferito();
				paragrafiCollegati.add(listaParagrafi.get(idRiferimento));
			}
		}
	}
	
	public int scegliOpzione(int idParagrafo) {
		String scelta="";
		Paragrafo riferimento=listaParagrafi.get(idParagrafo);
		ArrayList<Opzione> opzioni=riferimento.getListaOpzioni();
		if(opzioni.size()>0) {
			for(int i=0;i<opzioni.size();i++) {
				System.out.println("Collegati a "+opzioni.get(i).getIdParagrafoRiferito());
			}
			System.out.println("Digita il numero del paragrafo a cui collegarti: ");
			try {
			scelta=tastiera.next();
			if(isStringa(scelta))
				throw new InputMismatchException(); //input errato
			int sceltaIntera=Integer.parseInt(scelta);
			if(sceltaCorretta(sceltaIntera,opzioni))
				return sceltaIntera;
			throw new IllegalArgumentException();
			}catch(IllegalArgumentException | InputMismatchException e) {
				System.out.println("Scelta errata, riprova: ");
				return scegliOpzione(idParagrafo);
			}
		}
		else
			return -1; //storia terminata
	}
	
	
	
	public void stampaParagrafi() {
		for(int i=0;i<numeroParagrafi;i++)
			System.out.println(listaParagrafi.get(i).getDescrizione());
	}
	
	private boolean sceltaCorretta(int scelta, ArrayList<Opzione> opzioni) {
		for(int i=0;i<opzioni.size();i++) {
			if(opzioni.get(i).getIdParagrafoRiferito()==scelta)
				return true;
		}
		return false;
	}
	
	private boolean isStringa(String scelta) {
		if(scelta.charAt(0)<'0' && scelta.charAt(0)>'9')
			return true;
		return false;
	}
	/**
	 * � possibile che il primo paragrafo abbia zero opzioni anche se la storia � lunga pi�
	 * paragrafi, questo metodo lo evita riempiendo il primo paragrafo con 2 opzioni di default
	 */
	public void aggiustaPrimoParagrafo() {
		if(numeroParagrafi>1) {
			Paragrafo primoParagrafo=listaParagrafi.get(0);
			ArrayList<Opzione> listaOpzioni=primoParagrafo.getListaOpzioni();
			if(listaOpzioni.size()==0) {//se ha zero opzioni � necessario aggiungerle
				int numeroOpzioni=2;
				primoParagrafo.setNumeroOpzioni(numeroOpzioni);
				for(int i=0;i<numeroOpzioni;i++) {
					int idParagrafo=Math.abs(r.nextInt()%numeroParagrafi);
					primoParagrafo.aggiungiOpzione("Opzione "+i, idParagrafo);
				}
			}
		}
	}
	/**
	 * vedi spiegazione metodo controlla opzioni
	 */
	public void rimuoviRidondanze() {
		for(int i=0;i<listaParagrafi.size();i++) {
			listaParagrafi.get(i).controllaOpzioni();
		}
	}
	/**
	 * rimuove le opzioni dell'ultimo paragrafo in modo da auspicare una fine certa(riduce le
	 * probabilit� di loop)
	 */
	public void rimuoviOpzioniUltimoParagrafo() {
		Paragrafo ultimo=listaParagrafi.get(listaParagrafi.size()-1);//prendi l'ultimo paragrafo
		ultimo.rimuoviOpzioni();
	}
	
	public String getTitolo() {
		return titolo;
	}
	/**
	 * ossia dimensione del modulo 4
	 * @return
	 */
	public int getNumeroParagrafi() {
		return numeroParagrafi;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public void setNumeroParagrafi(int numeroParagrafi) {
		this.numeroParagrafi = numeroParagrafi;
	}

	public ArrayList<Paragrafo> getListaParagrafi() {
		return listaParagrafi;
	}

	public void setListaParagrafi(ArrayList<Paragrafo> listaParagrafi) {
		this.listaParagrafi = listaParagrafi;
	}
	/**
	 * richiesta del calcolo della verbosit� di una storia riguardo il modulo 4
	 * @return la media delle lunghezze delle descrizioni dei paragrafi
	 */
	public int getVerbosita() {
		int sommaCaratteri=0;
		for(int i=0;i<listaParagrafi.size();i++) {
			sommaCaratteri+=listaParagrafi.get(i).getDescrizione().length();
		}
		return sommaCaratteri/listaParagrafi.size();
	}
	/**
	 * calcola la complessit� dell'intreccio della storia riguardo il modulo 4
	 * @return la media del numero di opzioni per ciascun paragrafo
	 */
	public int getComplessitaIntreccio() {
		int sommaOpzioni=0;
		for(int i=0;i<listaParagrafi.size();i++) {
			sommaOpzioni+=listaParagrafi.get(i).getNumeroOpzioni();
		}
		return sommaOpzioni/listaParagrafi.size();
	}
	
	
	
	
	

}
